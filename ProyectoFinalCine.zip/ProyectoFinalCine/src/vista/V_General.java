package vista;

import controlador.ControladorReserva;
import controlador.ControladorTarjeta;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import modelo.Silla;
import modelo.Tarjeta;

public class V_General extends javax.swing.JFrame {

    DefaultListModel<String> modelo1 = new DefaultListModel<>();
    ControladorTarjeta controladorTarjeta = new ControladorTarjeta();
    ControladorReserva controladorReserva = new ControladorReserva();
    Silla conSilla = new Silla();
    Tarjeta tar = new Tarjeta();

    JToggleButton[][] sillasBoton = new JToggleButton[14][20];
    private int[][] arr = new int[14][20];
    private boolean hab = false;
    private int flag = 0;
    private int contador = 0;
    private int dineroCaja = 0;
    private int disponibles = 280;
    private int vendidas = 0;
    private String imCedula = "";
    private String estadoPago = "SIN RESERVAS";

    public void cargarSillasBoton() {
        sillas.setLayout(new GridLayout(14, 20));
        for (int i = 0; i < 14; i++) {
            char letra = (char) (65 + i);
            for (int j = 0; j < 20; j++) {
                sillasBoton[i][j] = new JToggleButton(letra + "" + j);
                sillasBoton[i][j].setFont(sillasBoton[i][j].getFont().deriveFont((float) 5));
                sillasBoton[i][j].setBackground(Color.WHITE);
                sillasBoton[i][j].setName(letra + "" + j);
                sillas.add(sillasBoton[i][j]);
                sillasBoton[i][j].addItemListener(itemListener);
            }
        }   
        habilitar(hab);
    }

    ItemListener itemListener = new ItemListener() {

        public void itemStateChanged(ItemEvent itemEvent) {
            String cad = "";
            int cont = 0;
            if (contador == 0) {
                sillasImprimir.setText("");
                cont = 0;
                cad = "";
            }
            for (int i = 0; i < 14; i++) {
                for (int j = 0; j < 20; j++) {
                    if (arr[i][j] == 3) {
                        sillasBoton[i][j].setEnabled(false);
                    } else if (cont <= 8) {
                        if (sillasBoton[i][j].isSelected()) {
                            sillasBoton[i][j].setBackground(Color.YELLOW);
                            cad += "-" + sillasBoton[i][j].getName();
                            sillasImprimir.setText(cad);
                            cont++;
                            contador = cont;
                            arr[i][j] = 1;
                            disponiblesLabel.setText(Integer.toString(disponibles - cont));
                            estadoImprimir.setText("SIN PAGAR");
                        } else {
                            sillasBoton[i][j].setBackground(Color.WHITE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "SOLO PUEDE SELECCIONAR 8 SILLAS COMO MAXIMO", "ERROR", JOptionPane.ERROR_MESSAGE);
                        cont--;
                        contador = cont;
                    }
                }
            }
        }
    };

    public V_General() {
        initComponents();
        cargarSillasBoton();
        disponiblesLabel.setText(Integer.toString(disponibles));
        vendidasLabel.setText(Integer.toString(vendidas));
        dineroLabel.setText(Integer.toString(dineroCaja));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        principal = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        sillasVendidas = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        vendidasLabel = new javax.swing.JLabel();
        dineroLabel = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        disponiblesLabel = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        tarjeta = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        cedulaTexto = new javax.swing.JTextField();
        saldoTexto = new javax.swing.JTextField();
        guardarTarjeta = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tarjetasLista = new javax.swing.JList<>();
        jPanel5 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        cedulaRecargar = new javax.swing.JTextField();
        saldoRecargar = new javax.swing.JTextField();
        recargarTarjeta = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        reservas = new javax.swing.JPanel();
        sillas = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        reservaBox = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        agregarReserva = new javax.swing.JToggleButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        eliminarReserva = new javax.swing.JToggleButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        PagoEfectivo = new javax.swing.JToggleButton();
        PagoTarjeta = new javax.swing.JToggleButton();
        cedulaImprimir = new javax.swing.JLabel();
        estadoImprimir = new javax.swing.JLabel();
        sillasImprimir = new javax.swing.JLabel();
        guardarReserva = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SALA DE CINE ");
        setBackground(new java.awt.Color(51, 51, 51));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        principal.setBackground(new java.awt.Color(0, 153, 153));

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        jLabel10.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("INFORMACION GENERAL ");

        jLabel20.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("SILLAS VENDIDAS:");

        jLabel21.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 0));

        sillasVendidas.setForeground(new java.awt.Color(0, 0, 0));
        sillasVendidas.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                sillasVendidasAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        jLabel30.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 0, 0));
        jLabel30.setText("DINERO EN CAJA:");

        vendidasLabel.setForeground(new java.awt.Color(0, 0, 0));
        vendidasLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        dineroLabel.setForeground(new java.awt.Color(0, 0, 0));
        dineroLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel19.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("SILLAS DISPONIBLES:");

        disponiblesLabel.setForeground(new java.awt.Color(0, 0, 0));
        disponiblesLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jLabel10))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(disponiblesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel30)
                                        .addGap(41, 41, 41)
                                        .addComponent(dineroLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addGap(32, 32, 32)
                                        .addComponent(vendidasLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(sillasVendidas))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(91, 91, 91)
                                        .addComponent(jLabel21)))))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel21)
                    .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dineroLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(sillasVendidas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel19)
                    .addComponent(disponiblesLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(vendidasLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fb6091b95fe7-2_poster_480x670.png"))); // NOI18N
        jLabel22.setText("jLabel22");

        jLabel23.setFont(new java.awt.Font("Impact", 0, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("CARTELERA");

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ARTE - SPACE JAM UNA NUEVA ERA.png"))); // NOI18N
        jLabel24.setText("jLabel22");

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1e427f4e9c9c-poster_carrusel_575.jpg"))); // NOI18N
        jLabel25.setText("jLabel22");

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cine-5-e1585960007845.jpg"))); // NOI18N
        jLabel26.setText("jLabel26");

        javax.swing.GroupLayout principalLayout = new javax.swing.GroupLayout(principal);
        principal.setLayout(principalLayout);
        principalLayout.setHorizontalGroup(
            principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(principalLayout.createSequentialGroup()
                .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(principalLayout.createSequentialGroup()
                        .addGap(204, 204, 204)
                        .addComponent(jLabel23))
                    .addGroup(principalLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(1, 16, Short.MAX_VALUE)
                .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(137, 137, 137))
        );
        principalLayout.setVerticalGroup(
            principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(principalLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(principalLayout.createSequentialGroup()
                        .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, principalLayout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(25, 25, 25))
                    .addGroup(principalLayout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addGap(43, 43, 43)
                        .addGroup(principalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("PRINCIPAL", principal);

        tarjeta.setBackground(new java.awt.Color(0, 102, 51));

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel9.setText("TARJETAS");

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel12.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("SALDO:");

        cedulaTexto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                cedulaTextoKeyTyped(evt);
            }
        });

        saldoTexto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                saldoTextoKeyTyped(evt);
            }
        });

        guardarTarjeta.setBackground(new java.awt.Color(153, 153, 153));
        guardarTarjeta.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        guardarTarjeta.setForeground(new java.awt.Color(0, 0, 0));
        guardarTarjeta.setText("GUARDAR");
        guardarTarjeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarTarjetaActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("CEDULA:");

        jLabel13.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("CREAR UNA  NUEVA TARJETA");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cedulaTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(saldoTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(guardarTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(41, 41, 41))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cedulaTexto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(saldoTexto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(guardarTarjeta)
                .addGap(14, 14, 14))
        );

        jPanel4.setBackground(new java.awt.Color(0, 153, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel16.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("TARJETAS REGISTRADAS");

        tarjetasLista.setForeground(new java.awt.Color(0, 0, 0));
        tarjetasLista.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tarjetasListaMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tarjetasLista);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(41, 41, 41))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(0, 153, 51));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jLabel14.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("SALDO:");

        recargarTarjeta.setBackground(new java.awt.Color(153, 153, 153));
        recargarTarjeta.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        recargarTarjeta.setForeground(new java.awt.Color(0, 0, 0));
        recargarTarjeta.setText("RECARGAR");
        recargarTarjeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recargarTarjetaActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("CEDULA:");

        jLabel17.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("RECARGAR TARJETA");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cedulaRecargar, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(saldoRecargar, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(41, 41, 41))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(recargarTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(cedulaRecargar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(saldoRecargar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(recargarTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/24-3.jpg"))); // NOI18N
        jLabel27.setText("jLabel27");

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/movie-tickets-design-template-f8.jpg"))); // NOI18N
        jLabel28.setText("jLabel28");

        javax.swing.GroupLayout tarjetaLayout = new javax.swing.GroupLayout(tarjeta);
        tarjeta.setLayout(tarjetaLayout);
        tarjetaLayout.setHorizontalGroup(
            tarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tarjetaLayout.createSequentialGroup()
                .addGap(444, 444, 444)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(tarjetaLayout.createSequentialGroup()
                .addGroup(tarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tarjetaLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tarjetaLayout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(38, 38, 38)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                .addGroup(tarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );
        tarjetaLayout.setVerticalGroup(
            tarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tarjetaLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addGroup(tarjetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tarjetaLayout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tarjetaLayout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("TARJETAS", tarjeta);

        reservas.setBackground(new java.awt.Color(0, 102, 153));
        reservas.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                reservasAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        javax.swing.GroupLayout sillasLayout = new javax.swing.GroupLayout(sillas);
        sillas.setLayout(sillasLayout);
        sillasLayout.setHorizontalGroup(
            sillasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 687, Short.MAX_VALUE)
        );
        sillasLayout.setVerticalGroup(
            sillasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("RESERVAS");

        reservaBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                reservaBoxItemStateChanged(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Palatino Linotype", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("RESERVA");

        agregarReserva.setText("AGREGAR RESERVA");
        agregarReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarReservaActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("RESERVA ACTUAL");

        jLabel4.setText("CEDULA:");

        jLabel5.setText("ESTADO DE PAGO:");

        eliminarReserva.setText("ELIMINAR RESERVA");
        eliminarReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarReservaActionPerformed(evt);
            }
        });

        jLabel6.setText("SILLAS RESERVADAS ");

        jLabel7.setText("REGISTRAR PAGO");

        PagoEfectivo.setText("PAGO EFECTIVO");
        PagoEfectivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PagoEfectivoActionPerformed(evt);
            }
        });

        PagoTarjeta.setText("PAGO TARJETA");
        PagoTarjeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PagoTarjetaActionPerformed(evt);
            }
        });

        cedulaImprimir.setBackground(new java.awt.Color(204, 204, 204));
        cedulaImprimir.setForeground(new java.awt.Color(0, 0, 0));
        cedulaImprimir.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                cedulaImprimirAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        estadoImprimir.setBackground(new java.awt.Color(255, 255, 255));
        estadoImprimir.setForeground(new java.awt.Color(0, 0, 0));

        sillasImprimir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        guardarReserva.setText("GUARDAR");
        guardarReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarReservaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout reservasLayout = new javax.swing.GroupLayout(reservas);
        reservas.setLayout(reservasLayout);
        reservasLayout.setHorizontalGroup(
            reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservasLayout.createSequentialGroup()
                .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(reservasLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(579, 579, 579))
                    .addGroup(reservasLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(sillas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reservasLayout.createSequentialGroup()
                            .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(agregarReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(reservaBox, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(eliminarReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(reservasLayout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(cedulaImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel2))
                            .addGap(56, 56, 56))
                        .addGroup(reservasLayout.createSequentialGroup()
                            .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(reservasLayout.createSequentialGroup()
                                        .addComponent(PagoEfectivo)
                                        .addGap(18, 18, 18)
                                        .addComponent(PagoTarjeta))
                                    .addGroup(reservasLayout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(estadoImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(reservasLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(sillasImprimir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(reservasLayout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(jLabel6)))
                            .addContainerGap()))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reservasLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 166, Short.MAX_VALUE)
                        .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(guardarReserva)
                            .addComponent(jLabel7))
                        .addGap(115, 115, 115))))
        );
        reservasLayout.setVerticalGroup(
            reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reservasLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(reservasLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reservaBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(agregarReserva)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eliminarReserva)
                        .addGap(3, 3, 3)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cedulaImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(estadoImprimir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sillasImprimir, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(guardarReserva)
                        .addGap(9, 9, 9)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(reservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PagoTarjeta)
                            .addComponent(PagoEfectivo)))
                    .addGroup(reservasLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(sillas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(37, 37, 37))
        );

        jTabbedPane1.addTab("RESERVAS", reservas);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/1.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(296, 296, 296)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1068, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(122, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void agregarReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarReservaActionPerformed
        String ced;
        int cedula;
        ced = JOptionPane.showInputDialog(null, "CEDULA", JOptionPane.QUESTION_MESSAGE);
        cedula = new Integer(ced);
        if (ced.equals("")) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR ALGO EN EL CAMPO", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        if (controladorReserva.validarCedula(cedula) == true) {
            JOptionPane.showMessageDialog(null, "ESTA CEDULA SE ENCUENTRA YA SE ENCUENTRA INSCRITA", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            controladorReserva.inscribir(cedula);
            if (flag == 0) {
                habilitar(true);
            }
            flag = 1;
            contador = 0;
            reservaBox.addItem(ced);
            cedulaImprimir.setText(ced);
            estadoImprimir.setText(estadoPago);
        }
    }//GEN-LAST:event_agregarReservaActionPerformed

    private void PagoEfectivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PagoEfectivoActionPerformed
        int cedu = Integer.parseInt(reservaBox.getSelectedItem().toString());
        int iterador = 0;
        int error = 0;
        double totalPagar = 0;
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 20; j++) {
                if (arr[i][j] == 1) {
                    iterador++;
                }
            }
        }
        controladorReserva.restarSillas(cedu, iterador);
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 20; j++) {
                if (controladorReserva.deshabilitarCompras(cedu) == false) {
                    if (arr[i][j] == 1) {
                        controladorReserva.sillasDisponibles(cedu);
                        contador = 0;
                        sillasBoton[i][j].setEnabled(false);
                        //sillasBoton[i][j].setBackground(Color.red);
                        sillasImprimir.setText("");
                        arr[i][j] = 3;
                        if (i < 11) {
                            totalPagar += 15000;
                        } else if (i >= 11) {
                            totalPagar += 25000;
                        }
                        disponibles--;
                        disponiblesLabel.setText(String.valueOf(disponibles));
                        vendidas++;
                        vendidasLabel.setText(String.valueOf(vendidas));
                        controladorReserva.pagar(cedu);
                        controladorReserva.stringPago(cedu);
                        controladorReserva.pagar(cedu);
                        controladorReserva.stringPago(cedu);
                    }
                } else {
                    error++;
                }
            }
        }
        if (error > 0) {
            JOptionPane.showMessageDialog(null, "SOLO 8 SILLAS POR PERSONA", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            estadoImprimir.setText(controladorReserva.stringPago(cedu));
            this.dineroCaja += totalPagar;
            dineroLabel.setText(Integer.toString(dineroCaja));
            JOptionPane.showMessageDialog(null, "PAGO CON CREDITO REALIZADO", "PAGADO", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_PagoEfectivoActionPerformed

    private void reservasAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_reservasAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_reservasAncestorAdded

    private void cedulaImprimirAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_cedulaImprimirAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_cedulaImprimirAncestorAdded

    private void reservaBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_reservaBoxItemStateChanged
        imCedula = (String) reservaBox.getSelectedItem();
        int ced = Integer.parseInt(imCedula);
        cedulaImprimir.setText(imCedula);
        estadoImprimir.setText(controladorReserva.stringPago(ced));
    }//GEN-LAST:event_reservaBoxItemStateChanged

    private void guardarTarjetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarTarjetaActionPerformed
        if (cedulaTexto.getText().equals("") || saldoTexto.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR ALGO EN LOS CAMPOS", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            int cedulaEnviar = Integer.parseInt(cedulaTexto.getText());
            double sald = Double.parseDouble(saldoTexto.getText());

            if (controladorTarjeta.validarTarjeta(cedulaEnviar) == false) {//Si es false quiere decir que no existe tarjeta creada
                if (sald == 100000 && cedulaEnviar > 0) {
                    controladorTarjeta.CrearTarjeta(cedulaEnviar, sald, true);
                    //instancias con sala controladorTarjeta.dineroCaja(saldo);
                    JOptionPane.showMessageDialog(null, "TARJETA CREADA EXITOSAMENTE", "", JOptionPane.INFORMATION_MESSAGE);
                    tarjetasLista.setModel(modelo1);//Seteamos el modelo para la lista de tarjetas
                    modelo1.addElement(Integer.toString(cedulaEnviar));
                    this.dineroCaja += 100000;
                    dineroLabel.setText(Integer.toString(dineroCaja));
                    cedulaTexto.setText("");
                    saldoTexto.setText("");

                } else {
                    JOptionPane.showMessageDialog(null, "CEDULA O SALDO INVALIDOS", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            } else if (controladorTarjeta.validarTarjeta(cedulaEnviar) == true) {
                JOptionPane.showMessageDialog(null, "LA CEDULA SE ENCUENTRA INSCRITA EN OTRA TARJETA", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_guardarTarjetaActionPerformed

    private void recargarTarjetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recargarTarjetaActionPerformed
        int cedRecargar = Integer.valueOf(cedulaRecargar.getText());
        try {
            if (controladorTarjeta.validarTarjeta(cedRecargar) == true) {
                double saldo = 100000;
                controladorTarjeta.recargarTarjeta(cedRecargar, saldo);
                this.dineroCaja += 100000;
                dineroLabel.setText(Integer.toString(dineroCaja));
                saldoRecargar.setText(Double.toString(controladorTarjeta.dineroTarjeta(cedRecargar)));//pegar en toString Double.valueOf(saldoRecargar.getText()) + saldo)
            } else {
                JOptionPane.showMessageDialog(null, "NO POSEE UNA TARJETA ACTUALMENTE", "ERROR", JOptionPane.ERROR_MESSAGE);
            }

        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, "DEBE SELECCIONAR ALGO", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_recargarTarjetaActionPerformed

    private void cedulaTextoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cedulaTextoKeyTyped
        Character digit = evt.getKeyChar();
        if (!Character.isDigit(digit)) {
            evt.consume();
        }
    }//GEN-LAST:event_cedulaTextoKeyTyped

    private void saldoTextoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_saldoTextoKeyTyped
        Character digit = evt.getKeyChar();
        if (!Character.isDigit(digit)) {
            evt.consume();
        }
    }//GEN-LAST:event_saldoTextoKeyTyped

    private void tarjetasListaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tarjetasListaMousePressed
        try {
            int cedulaTemp = Integer.valueOf(tarjetasLista.getSelectedValue());
            cedulaRecargar.setText(Integer.toString(cedulaTemp));
            saldoRecargar.setText(Double.toString(controladorTarjeta.dineroTarjeta(cedulaTemp)));
        } catch (Exception e) {

        }
    }//GEN-LAST:event_tarjetasListaMousePressed

    private void eliminarReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarReservaActionPerformed
        int indice = reservaBox.getSelectedIndex();
        int ced = Integer.parseInt(reservaBox.getSelectedItem().toString());
        System.out.println("HA ENTRADO");
        if (controladorReserva.estadoPagado(ced) == false) {
            for (int i = 0; i < 14; i++) {
                for (int j = 0; j < 20; j++) {
                    if (arr[i][j] == 1) {
                        arr[i][j] = 0;
                        sillasBoton[i][j].setBackground(Color.WHITE);
                    }
                }
            }
            //controladorReserva.CrearReserva(0, null, 0, false);
            controladorReserva.eliminarReserva(ced);
            contador = 0;
            reservaBox.removeItemAt(indice);
            cedulaImprimir.setText("");
            estadoImprimir.setText("");
            sillasImprimir.setText("");
            if (reservaBox.getSelectedIndex() == -1) {
                for (int i = 0; i < 14; i++) {
                    for (int j = 0; j < 20; j++) {
                        sillasBoton[i][j].setEnabled(false);
                    }
                }
            }
            System.out.println("HA SALIDO");
        } else {
            JOptionPane.showMessageDialog(null, "NO SE PUEDE ELIMINAR, HA SIDO PAGADO", "INFO", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_eliminarReservaActionPerformed

    private void PagoTarjetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PagoTarjetaActionPerformed
        int cedu = Integer.parseInt(reservaBox.getSelectedItem().toString());
        double totalPagar = 0;
        int iterador = 0;
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 20; j++) {
                if (arr[i][j] == 1) {
                    iterador++;
                }
            }
        }
        controladorReserva.restarSillas(cedu, iterador);

        if (controladorTarjeta.validarTarjeta(cedu) == true) {
            if (controladorTarjeta.dineroTarjeta(cedu) >= totalPagar) {
                for (int i = 0; i < 14; i++) {
                    for (int j = 0; j < 20; j++) {
                        if (controladorReserva.deshabilitarCompras(cedu) == false) {
                            if (arr[i][j] == 1) {
                                contador = 0;
                                sillasBoton[i][j].setEnabled(false);
                                //sillasBoton[i][j].setBackground(Color.red);
                                sillasImprimir.setText("");
                                if (i < 11 && arr[i][j] == 1) {
                                    totalPagar += 15000;
                                } else if (i >= 11 && arr[i][j] == 1) {
                                    totalPagar += 25000;
                                }
                                arr[i][j] = 3;
                                disponibles--;
                                disponiblesLabel.setText(String.valueOf(disponibles));
                                vendidas++;
                                vendidasLabel.setText(String.valueOf(vendidas));
                                //sillasBoton[i][j].setBackground(Color.red);
                                controladorTarjeta.pagoTarjeta(cedu, totalPagar);
                                controladorReserva.pagar(cedu);
                                controladorReserva.stringPago(cedu);
                                sillasImprimir.setText("");
                                controladorReserva.pagar(cedu);
                                controladorReserva.stringPago(cedu);
                            }
                        }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "FONDOS INSUFICIENTES EN LA TARJETA", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "PARA REALIZAR ESTE TIPO DE PAGO PRIMERO CREA UNA TARJETA", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        if (controladorReserva.estadoPagado(cedu) == true) {
            estadoImprimir.setText(controladorReserva.stringPago(cedu));
            this.dineroCaja += totalPagar;
            dineroLabel.setText(Integer.toString(dineroCaja));
            JOptionPane.showMessageDialog(null, "PAGO CON TARJETA EXITOSO", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_PagoTarjetaActionPerformed

    private void sillasVendidasAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_sillasVendidasAncestorAdded

    }//GEN-LAST:event_sillasVendidasAncestorAdded

    private void guardarReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarReservaActionPerformed
        int cedu = Integer.parseInt(reservaBox.getSelectedItem().toString());
        int numeroSillas = 0;
        int[][] matriz = arr;
        //int[][] temp= new int[14][20];
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 20; j++) {
                if (matriz[i][j] == 1) {
                    numeroSillas++;
                }
            }
        }
        if (controladorReserva.sillasDisponibles(cedu) >= numeroSillas && numeroSillas <= 8) {
            controladorReserva.CrearReserva(cedu, matriz, numeroSillas, false);
            contador = 0;
            JOptionPane.showMessageDialog(null, "RESERVA GUARDADA", "GUARDADO", JOptionPane.INFORMATION_MESSAGE);
            flag = 0;
            PagoEfectivo.setEnabled(true);
            PagoTarjeta.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(null, "NO PUEDE RESERVAR MAS SILLAS", "ERROR", JOptionPane.ERROR_MESSAGE);
            PagoEfectivo.setEnabled(false);
            PagoTarjeta.setEnabled(false);
        }
    }//GEN-LAST:event_guardarReservaActionPerformed

    public void habilitar(boolean hab) {
        for (int i = 0; i < 14; i++) {
            for (int j = 0; j < 20; j++) {
                sillasBoton[i][j].setEnabled(hab);
            }
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(V_General.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(V_General.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(V_General.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(V_General.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new V_General().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton PagoEfectivo;
    private javax.swing.JToggleButton PagoTarjeta;
    private javax.swing.JToggleButton agregarReserva;
    private javax.swing.JLabel cedulaImprimir;
    private javax.swing.JTextField cedulaRecargar;
    private javax.swing.JTextField cedulaTexto;
    private javax.swing.JLabel dineroLabel;
    private javax.swing.JLabel disponiblesLabel;
    private javax.swing.JToggleButton eliminarReserva;
    private javax.swing.JLabel estadoImprimir;
    private javax.swing.JButton guardarReserva;
    private javax.swing.JButton guardarTarjeta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel principal;
    private javax.swing.JButton recargarTarjeta;
    private javax.swing.JComboBox<String> reservaBox;
    private javax.swing.JPanel reservas;
    private javax.swing.JTextField saldoRecargar;
    private javax.swing.JTextField saldoTexto;
    private javax.swing.JPanel sillas;
    private javax.swing.JLabel sillasImprimir;
    private javax.swing.JLabel sillasVendidas;
    private javax.swing.JPanel tarjeta;
    private javax.swing.JList<String> tarjetasLista;
    private javax.swing.JLabel vendidasLabel;
    // End of variables declaration//GEN-END:variables
}
