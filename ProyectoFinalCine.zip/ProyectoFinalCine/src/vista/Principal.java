package vista;

public class Principal {

    public static void main(String[] args) {
        V_General objetoGeneral= new V_General();
        objetoGeneral.setVisible(true);
    }
    
}
