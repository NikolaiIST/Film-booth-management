package modelo;

public abstract class Sala {
    private double dinerocajaToltal;
    public abstract void calculardinero();

    public double getDinerocajaToltal() {
        return dinerocajaToltal;
    }

    public void setDinerocajaToltal(double dinerocajaToltal) {
        this.dinerocajaToltal = dinerocajaToltal;
    }
    
}
