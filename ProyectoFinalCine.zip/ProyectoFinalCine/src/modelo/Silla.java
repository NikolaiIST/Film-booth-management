package modelo;

import java.io.Serializable;

public class Silla extends Sala implements Serializable  {
    private int cedula;
    private int[][] estadosilla;
    private String estadoPago;
    private int numSillas=8;
    private boolean pagado;

    public Silla() {
    }

    public Silla(int cedula, int[][] estadosilla, String estadoPago, int numSillas, boolean pagado) {
        this.cedula = cedula;
        this.estadosilla = estadosilla;
        this.estadoPago = estadoPago;
        this.numSillas-=numSillas;
        this.pagado=pagado;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public void setEstadosilla(int [][]estadosilla) {
        this.estadosilla=estadosilla;
    }

    public int [][] getEstadosilla () {
         return estadosilla;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }

    public int getNumSillas() {
        return numSillas;
    }
     public void setNumSillas(int numSillas) {
        this.numSillas -= numSillas;
    }

    @Override
    public void calculardinero() {
       
    }
    public boolean getPagado() {
        return pagado;
    }
    public void setPagado(boolean pagado) {
        this.pagado = pagado;
    }
}
