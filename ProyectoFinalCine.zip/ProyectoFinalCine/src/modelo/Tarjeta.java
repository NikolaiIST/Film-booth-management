package modelo;

import java.io.Serializable;

public class Tarjeta extends Sala implements Serializable{
    
    private int cedula;
    private double saldoTarjeta;
    private boolean tarjeta;

    public Tarjeta() {
    }

    public Tarjeta(int cedula, double saldoTarjeta, boolean tarjeta) {
        this.cedula = cedula;
        this.saldoTarjeta = saldoTarjeta;
        this.tarjeta = tarjeta;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public double getSaldoTarjeta() {
        return saldoTarjeta;
    }

    public void setSaldoTarjeta(double saldoTarjeta) {
        this.saldoTarjeta += saldoTarjeta;
    }

    public boolean isTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(boolean tarjeta) {
        this.tarjeta = tarjeta;
    }

    @Override
    public String toString() {
        return "Tarjeta{" + "cedula=" + cedula + ", saldoTarjeta=" + saldoTarjeta + ", tarjeta=" + tarjeta + '}';
    }

    @Override
    public void calculardinero() {
        double totalTarje=0;
        totalTarje+=this.saldoTarjeta;        
        super.setDinerocajaToltal(totalTarje);
    }

}
