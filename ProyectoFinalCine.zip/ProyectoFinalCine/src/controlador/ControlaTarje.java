package controlador;

public interface ControlaTarje {
    
    public void CrearTarjeta(int cedula, double saldo, boolean tarjeta);
    public boolean validarTarjeta(int cedula);
    public void recargarTarjeta(int cedula, double saldo);
    public double dineroTarjeta(int cedula);
    public void pagoTarjeta(int cedula, double dinero);
}
