package controlador;

import java.util.ArrayList;
import modelo.Tarjeta;

public class ControladorTarjeta implements ControlaTarje {

    static ArrayList<Tarjeta> objTarjeta = new ArrayList<Tarjeta>();
    Tarjeta aux= new Tarjeta();
    Archivo archivo= new Archivo();
    
    @Override
    public void CrearTarjeta(int cedula, double saldo, boolean tarjeta){    
            aux= new Tarjeta(cedula, saldo, tarjeta);
            objTarjeta.add(aux);
            archivo.guardarArchivo(objTarjeta,"tarjeta");
    }
    
    @Override
    public boolean validarTarjeta(int cedula){
        for(Tarjeta buscar: objTarjeta){
            if(buscar.getCedula()==cedula){
                return true;//YA POSEE UNA TARJETA
            }
        }
        return false;//NO TIENE TARJETA
    }
    
    @Override
    public void recargarTarjeta(int cedula, double saldo) {
        for (Tarjeta buscar : objTarjeta) {
            if (cedula == buscar.getCedula()){
                buscar.setSaldoTarjeta(saldo);
                archivo.guardarArchivo(objTarjeta,"tarjeta");
            }
        }
    }
    
    @Override
    public double dineroTarjeta(int cedula){
        double saldoTotal=0;
        
        for (Tarjeta buscar : objTarjeta) {
            if(buscar.getCedula()==cedula){
                saldoTotal=buscar.getSaldoTarjeta();
            }
        }
        return saldoTotal;
    }
    @Override
    public void pagoTarjeta(int cedula, double dinero){
        for (Tarjeta buscar : objTarjeta) {
            if(buscar.getCedula()==cedula){
                buscar.setSaldoTarjeta(buscar.getSaldoTarjeta()-dinero);
                archivo.guardarArchivo(objTarjeta,"tarjeta");
            }
        }
    }
    
    public void inicioArray() {
        try {
            if (archivo.leerArchivo("tarjeta") != null) {
                if (objTarjeta.isEmpty()) {
                    objTarjeta = archivo.leerArchivo("tarjeta");
                }
            }

        } catch (Exception e) {
            System.out.println("NO SE PUDO IMPORTAR EL ARRAYLIST ó NO HAY ARCHIVOS GUARDADOS" + e);
        }
    }//CARGA LOS ARCHIVO SERIALIZABLES QUE HEMOS GENERADO PARA LLENAR EL ARRAY LIST 

    
}
