package controlador;

public interface ControlaReserva {
    
    public boolean CrearReserva(int cedula, int[][] estadosilla, int numSillas, boolean pagado);
    public void inscribir(int cedula);
    public boolean validarCedula(int ced);
    public boolean eliminarReserva(int ced);
    public boolean estadoPagado(int cedula);
    public String stringPago(int ced);
    public void pagar(int ced);
    public int sillasDisponibles(int cedula);
    public int[][] sillasReservadas(int ced);
    public void restarSillas(int ced, int iterador);
    public boolean deshabilitarCompras(int ced);
}
