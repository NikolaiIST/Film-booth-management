package controlador;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Silla;

public class ControladorReserva implements ControlaReserva {

    static ArrayList<Silla> objSilla = new ArrayList<Silla>();
    ControladorTarjeta conTarjeta = new ControladorTarjeta();
    Silla aux = new Silla();
    Archivo archivo= new Archivo();

    @Override
    public boolean CrearReserva(int cedula, int[][] estadoSilla, int numSillas, boolean pagado) {
        String estadoPagado="SIN RESERVAS";
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == cedula) {
                JOptionPane.showMessageDialog(null, "ESTA CEDULA YA ESTÁ INSCRITA", "ERROR", JOptionPane.ERROR_MESSAGE);//SI ES TRUE QUIERE DECIR QUE YA ESTÁ INSCRITA ESTA CEDULA
                return false;
            }
        }
        aux = new Silla(cedula, estadoSilla, estadoPagado, numSillas, pagado);
        objSilla.add(aux);
        archivo.guardarArchivo(objSilla,"reserva");
        return true;
    }
    
    @Override
    public void inscribir(int cedula){
        aux = new Silla(cedula, null, null, 0, false);
        objSilla.add(aux);
        archivo.guardarArchivo(objSilla,"reserva");
    }

    @Override
    public boolean validarCedula(int ced) {
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == ced) {
                return true;//SI ES TRUE QUIERE DECIR QUE YA ESTÁ INSCRITA ESTA CEDULA
            }
        }
        
        return false;
    }

    @Override
    public boolean eliminarReserva(int ced) {
        for (Silla i : objSilla) {
            if (i.getCedula() == ced) {
                objSilla.remove(i);
                archivo.guardarArchivo(objSilla,"reserva");
                return true;
            }
        }
        return false;
    }

    @Override
    public int sillasDisponibles(int cedula) {
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == cedula) {
                return buscar.getNumSillas();
            }
        }
        return 0;
    }

    @Override
    public boolean estadoPagado(int cedula) {
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == cedula) {
                if (buscar.getPagado() == true) {
                    return true;//YA HA PAGADO ALMENOS UNA RESERVA
                }
            }
        }
        return false;//NO HA PAGAO
    }
    @Override
    public String stringPago(int ced){
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == ced) {
                buscar.setEstadoPago("PAGADO");
                 return buscar.getEstadoPago();
            }
        }   
       return "";
    }
     @Override
    public void pagar(int ced) {
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == ced) {
                buscar.setEstadoPago("PAGADO");
                buscar.setPagado(true);
            }
        }        
    }
    @Override
    public int[][] sillasReservadas(int ced) {
        int[][] estado = new int[14][20];
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == ced) {
                estado = buscar.getEstadosilla();
            }
        }
        return estado;
    }
    @Override
    public void restarSillas(int ced, int iterador){
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == ced) {
                if(buscar.getNumSillas()>0){
                    buscar.setNumSillas(iterador);
                }
            }
        }
    }
    @Override
    public boolean deshabilitarCompras(int ced){
        for (Silla buscar : objSilla) {
            if (buscar.getCedula() == ced) {
                if(buscar.getNumSillas()<0){
                    return true;
                }
            }
        }
        return false;
    }
    
        public void inicioArray() {
        try {
            if (archivo.leerArchivo("reserva") != null) {
                if (objSilla.isEmpty()) {
                    objSilla = archivo.leerArchivo("reserva");
                }
            }

        } catch (Exception e) {
            System.out.println("NO SE PUDO IMPORTAR EL ARRAYLIST ó NO HAY ARCHIVOS GUARDADOS" + e);
        }
    }//CARGA LOS ARCHIVO SERIALIZABLES QUE HEMOS GENERADO PARA LLENAR EL ARRAY LIST 
}
